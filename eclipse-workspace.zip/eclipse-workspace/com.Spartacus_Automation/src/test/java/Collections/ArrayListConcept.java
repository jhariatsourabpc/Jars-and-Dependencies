	package Collections;

import java.util.ArrayList;

public class ArrayListConcept {

	public static void main(String[] args) {
		
		// ArrayList : elements can be dynamically added (doubled) or removed from the list
		// 2. The size of the List is increased dynamically  if items are added more than initial size
		// 3. Contains duplicate element
		// 4. Maintains insertion Order
		// 5. Non Synchronized (Not thread Safe) - 
		// allows random access because it works on index basis
		
		ArrayList<Object> list = new ArrayList<Object>();
		list.add("Rishabh");
		list.add(12345);
		list.add("verma");
		list.add(2, "India");
		
		System.out.println(list);
		System.out.println(list.get(2));
		
		// Update elemnt in lIst
		list.set(2, "Australia");
		System.out.println(list.get(2));
		
		// Iterate using for Each loop
		
		for(Object num : list)
		{
			System.out.println("Iterating through For each loop -> " + num);
		}
		
		System.out.println("********************");
        // Iterate using for loop
		
		for(int i=0; i< list.size(); i++)
		{
			System.out.println("Iterating through For loop -> " + list.get(i));
		}

	}

}
