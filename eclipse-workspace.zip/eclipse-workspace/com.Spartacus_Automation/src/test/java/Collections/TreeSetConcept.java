package Collections;

import java.util.TreeSet;

public class TreeSetConcept {

	public static void main(String[] args) {
		
		// Non Synchronized
		// objects of this class are unique and are stored in ascending order
		// Doesn't allow null element
		// Contains unique elements
		
		TreeSet<Object> ts =new TreeSet<Object>();
		
		ts.add("Rishabh");
		ts.add("Shyam");
	
		ts.add("Shyam");
		
		ts.add("Om");
		ts.add("Abhishek");  // will display the results in ascending order
		
		for(Object m : ts)
		{
			System.out.println(m);
		}
	}

}
