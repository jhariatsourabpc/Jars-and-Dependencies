package Collections;

import java.util.HashSet;

public class HashSetConcepts {

	public static void main(String[] args) {
		
		// Set:  It is a collection that never stores duplicate value
		
		// HashSet: It contains unique elements
		// It allows null values
		//It is non Synchronized (Not thread safe) - Multiple threads can access single object at same time
		// Use hashing mechanism to store the elements
		// does not maintain insertion order. Elements are inserted on the basis of hashcode
		// Best approach for search operations
		
		HashSet<Object> set = new HashSet<Object>();
		
		set.add("Rishabh");
		set.add(12345);
		set.add("verma");
		set.add("verma");   // duplicate values is not allowed, if we pass value will be replaced by new value
		
		for(Object m : set)
		{
			System.out.println(m);
		}
		
		// to remove element
		
		set.remove("verma");
		
		System.out.println(set);

	}

}
