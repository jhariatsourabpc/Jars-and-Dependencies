package Collections;

import java.util.LinkedList;

public class LinkedListConcept {

	public static void main(String[] args) {
		
		// It is the sequence of links which contains items
		// Each link contains a connection to other link
		// contains duplicate elements
		// Maintains Insertion order
		//non synchronized
		// Manipulation is fast
		
		// Difference Between ArrayList and Linked List
		// ArrayList : Uses Dynamic array to store data whereas linkedList used singly/Doubly LinkList to store data
		// ArrayList: It is slow one element is removed all bits are shifted, linkedList is fast as no bit shifting is required
		// ArrayList: Better for sorting and accessing data, linked better for manipulation
		// ArrayList: It act as list as it implements List whereas, ilinkList act as list and Queue as it implements both

		LinkedList<String> link = new LinkedList<String>();
		
		link.add("Rishabh");
		link.add("Verma");
		link.add("India");
		link.add("Australia");
		
		link.add(2, "Sharma");
		
		System.out.println(link);
		
		link.set(2, "Khana");
		
		// Iterate using for Each loop
		
				for(String num : link)
				{
					System.out.println("Iterating through For each loop -> " + num);
				}
				
				System.out.println("********************");
		        // Iterate using for loop
				
				for(int i=0; i< link.size(); i++)
				{
					System.out.println("Iterating through For loop -> " + link.get(i));
				}

		
		// update list
		link.set(3, "khana");
		
		
	}

}
