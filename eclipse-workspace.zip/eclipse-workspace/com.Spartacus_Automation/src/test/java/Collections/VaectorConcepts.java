package Collections;

import java.util.Vector;

public class VaectorConcepts {

	public static void main(String[] args) {
		 // Similar to Arrayvec except it is synchronized
		
		Vector<Object> vec = new Vector<Object>();
		
		vec.add("Rishabh");
		vec.add(12345);
		vec.add("verma");
		vec.add(2, "India");
		
		System.out.println(vec);
		System.out.println(vec.get(2));
		
		// Update elemnt in vec
		vec.set(2, "Australia");
		System.out.println(vec.get(2));
		
		// Iterate using for Each loop
		
		for(Object num : vec)
		{
			System.out.println("Iterating through For each loop -> " + num);
		}
		
		System.out.println("********************");
        // Iterate using for loop
		
		for(int i=0; i< vec.size(); i++)
		{
			System.out.println("Iterating through For loop -> " + vec.get(i));
		}

	}

	}


