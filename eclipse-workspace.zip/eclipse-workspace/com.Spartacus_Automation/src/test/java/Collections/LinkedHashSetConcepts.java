package Collections;

import java.util.LinkedHashSet;

public class LinkedHashSetConcepts {

	public static void main(String[] args) {
		
		// It implements Set interface and extends hashTable
		// It extends HashSet class and implements Set interface
		// Contains unique elements
		//Maintains insertion order
		
		LinkedHashSet<Object> lh = new LinkedHashSet<Object>();
		
		lh.add("Rishabh");
		lh.add(12345);
		lh.add("Verma");
		
		for(Object m : lh)
		{
			System.out.println(m);
		}
		
		// to remove element
		
		lh.remove("Verma");
		
		System.out.println(lh);

	}

}
