
  package BaseSetUpClass;
  
  import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import
  org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Utilities.Extentmanager;
import io.github.bonigarcia.wdm.WebDriverManager;
  
  public class BaseClass {
  
      public static WebDriver driver;
	  
     public static ExtentReports extentReport;
  	public static ThreadLocal<ExtentTest> classLevelLog = new ThreadLocal<ExtentTest>();
  	public static ThreadLocal<ExtentTest> testLevelLog = new ThreadLocal<ExtentTest>();
  	public static ExtentTest test=null;
	   
	    
  	@BeforeSuite
	public void beforeSuite() {
  		
  		extentReport = Extentmanager
				.GetExtent("C:/Users/river3/eclipse-workspace/com.Spartacus_Automation/target/reports/Test_Report.html");
  		
  	}
  	
  	@BeforeClass
	public void beforeClass() {
		// ExtentTest test = new ExtentTest(getClass().getSimpleName());
		ExtentTest classLevelTest = extentReport.createTest(getClass().getSimpleName());
		classLevelLog.set(classLevelTest);
	}
  	
 
  @BeforeMethod
  public static void config(Method method) 
  {
	  
	  test = classLevelLog.get().createNode(method.getName());
		testLevelLog.set(test);
	  WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://ptspartacus.ikeadt.com/Login.aspx");
		
  }
  
   @AfterMethod
   public void afterMethod(ITestResult result) {
	   
	   		if (result.getStatus() == ITestResult.SUCCESS) {
	   			testLevelLog.get().pass("Test Case passed");
	   			System.out.println("This Test cases is passed");
	   		} else if (result.getStatus() == ITestResult.FAILURE) {
	   			testLevelLog.get().fail("This test case failed");
	   			System.out.println("This Test Case is failed");
	   		} else if (result.getStatus() == ITestResult.SKIP) {
	   			testLevelLog.get().skip("Test case skipped");
	   			System.out.println("Test Case is skipped");
	   		}
	   		extentReport.flush();
	   		
	   		//driver.close();
  
  
  
  }
  }
 