package com.Spartacus_Automation;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import BaseSetUpClass.BaseClass;
import pages.Base_Page;
import pages.Home_Page;

public class Recovery_TestCases extends BaseClass{

	
	@Test(enabled = true)
	public void login() {
		
		Home_Page hp = new Home_Page(driver);
		hp.RecoveryLogin();
		
	}
@Test(enabled = true , priority = 1)
public void AddStock() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoveryAddStock();
		
		
		
	}
/*
@Test(enabled = true, priority = 2)
public void DeleteStock() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoverydeleteStock();

	}


@Test(enabled = true, priority = 3)
public void IssueReport() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoveryIssueReport();
		
	}

@Test(enabled = false)
public void AddSparePart() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoveryAddSparePart();
		
	}

@Test(enabled = false)
public void AddLocation() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoveryAddLocation();
		
	}

@Test(enabled = false)
public void StockCheckInLocation() throws InterruptedException {
		
		Home_Page hp1 = new Home_Page(driver);
		hp1.RecoveryLogin().RecoveryAddLocationStockCheck();
		
	}

*/
}
