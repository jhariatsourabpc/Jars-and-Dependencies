package com.Spartacus_Automation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Cure {
	
	WebDriver driver;
	
	@BeforeClass
	public void BasicConfig()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	}
	
	@Test(priority = 1)
	public void CureLogin()
	{
		
		driver.get("http://ptspartacus.ikeadt.com/Login.aspx?ReturnUrl=%2fViews%2fDefault.aspx");
		driver.findElement(By.xpath("//*[@id=\"txtUser\"]")).sendKeys("river3");
		driver.findElement(By.xpath("//*[@id=\"txtPassword\"]")).sendKeys("Omsystem@23");
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		
		
		}
	
	@Test(priority = 2)
	public void raiseCureRequest() throws Exception
	{
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"Body_txtSearch\"]")).sendKeys("00355133");
		driver.findElement(By.xpath("//*[@id=\"Body_btnSearch\"]")).click();                  // click on search button
		driver.findElement(By.xpath("//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[1]")).click();  // dropdown
		driver.findElement(By.xpath("//*[@id=\"DataTables_Table_0\"]/tbody/tr[1]/td[7]/div")).click();   // Click on Report Issue
		//driver.findElement(By.xpath("//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[5]/div[2]")).click();  // click partial icon
		//WebDriverWait wait = new WebDriverWait(driver,20);
		//driver.findElement(By.cssSelector("#DataTables_Table_9 > tbody > tr:nth-child(2) > td.col-md-2.full-width.text-center.no-left-right-padding.cta > div > label")).click(); // click + button
		//driver.findElement(By.xpath("//*[@id=\"modalRequest\"]/div[2]/div/div[3]/button[2]")).click();  // Go to request form
		//driver.findElement(By.xpath("//*[@id=\"DataTables_Table_0\"]/tbody/tr[2]/td[6]/div[2]")).click();
		
		//driver.switchTo().window(First_Window);
		
		//driver.findElement(By.xpath("//*[@id=\"Modal_chkForSale_1\"]")).click();
		//driver.findElement(By.xpath("//*[@id=\"Body_rptPartDetail_txtQty_0\"]")).sendKeys("1");
		
		//driver.findElement(By.xpath("//*[@id=\"Body_rbtnLstSales_1\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver,20);
		WebElement webEle = driver.findElement(By.xpath("//div[@id='UnlinkRequestModal']/div[2]/div/div[2]/div/select[@id='Modal_ddlUnlinkRequestReason']"));
		Select select = new Select(webEle);
		select.selectByVisibleText("Article - spare part link is missing");
		driver.findElement(By.xpath("//*[@id=\"UnlinkRequestModal\"]/div[2]/div/div[3]/button[1]")).click(); // click on OK button
		//driver.findElement(By.xpath("//*[@id=\"Modal_LinkButton1\"]")).click();    // go to request button
		//driver.findElement(By.xpath("//*[@id=\"Body_rptPartDetail_txtQty_0\"]")).sendKeys("1");   // select value
		//WebElement webEle1 = driver.findElement(By.xpath("//*[@id=\"Body_ddlRequestReason\"]"));
		//Select select1 = new Select(webEle1);
		//select1.selectByVisibleText("Part was missing");
		//driver.findElement(By.xpath("//*[@id=\"Body_btnRequest\"]")).click();  // Send Request to Recovery
		//driver.findElement(By.xpath("//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")).click(); // Cancel Print
		//driver.findElement(By.xpath("//*[@id=\"IcompConfirmationModal\"]/div[2]/div/div[3]/button[1]")).click();
		//driver.findElement(By.xpath("//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")).click();
		
		
		
		
		
		
		
		
		
	}

}
