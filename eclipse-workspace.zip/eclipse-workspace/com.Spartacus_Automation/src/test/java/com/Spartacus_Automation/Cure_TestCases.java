package com.Spartacus_Automation;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import BaseSetUpClass.BaseClass;

import static BaseSetUpClass.BaseClass.*;
import pages.Home_Page;

public class Cure_TestCases extends BaseClass {
	
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	
	@Test(enabled = false)
	public void login()
	{

		
		Home_Page hp = new Home_Page(driver);
		hp.Cure_login();
		 
	}
	
	@Test(priority = 1,enabled = true)
	public void Cure_Handout_Request()
	{
		
		Home_Page hp = new Home_Page(driver);
		
		hp.Cure_login().Cure_han_Request();
		
	}
	
	@Test(priority = 2,enabled = false)
	public void Cure_Icomp_Request()
	{
	
		
		Home_Page hp = new Home_Page(driver);
		hp.Cure_login().Cure_icomp_Request();
		
	}
	
	@Test(priority = 4, enabled = true)
	public void Cure_Partial_Request()
	{
	
		htmlReporter = new ExtentHtmlReporter("C:/Users/river3/eclipse-workspace/com.Spartacus_Automation/target/reports/Cure_Partial.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		ExtentTest test = extent.createTest("Spartacus: CurePartial_Request", "It will Raise Handout Request");
		test.log(Status.INFO, "Partial Request : Test Case Started");
		Home_Page hp = new Home_Page(driver);
		hp.Cure_login().Cure_Partial_Request();
		test.log(Status.PASS, "Partial Request: Test Case Passed");
		extent.flush();
		
	}
	
	@Test(priority = 3,enabled = false)
	public void Cure_Issue_Report_Request() throws Throwable
	{
	
		Home_Page hp = new Home_Page(driver);
		hp.Cure_login().Cure_Issue_Report();
		
	}
	
}


