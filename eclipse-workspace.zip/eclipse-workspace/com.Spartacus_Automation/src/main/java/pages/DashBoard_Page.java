package pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;


public class DashBoard_Page extends Base_Page {
	
	public DashBoard_Page(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="//*[@id=\"Body_txtSearch\"]") 
	public WebElement cuSearch;
	
	@FindBy(xpath="//*[@id=\"Body_btnSearch\"]")
	public WebElement cuSearchbtn;
	
	@FindBy(xpath="//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[1]")
	public WebElement articlebtndropdown;
	
	@FindBy(xpath="//tr[@class='dataTableSubData col even']/td[@class= 'col-md-2 full-width text-center no-left-right-padding cta']/div[@class='col-sm-5 col-md-5 col-lg-4 col-lg-offset-2 button text-white HandOutBtn']")
	public WebElement handoutButton;
	
	@FindBy(xpath="//*[@id=\"modalRequest\"]/div[2]/div/div[3]/button[2]")
	public WebElement goToRequestForm;
	
	@FindBy(xpath="//*[@id=\"Body_rptPartDetail_txtQty_0\"]")
	public WebElement selectQuantity;
	
	@FindBy(xpath="//*[@id=\"Body_rbtnLstSales_1\"]")
	public WebElement selectforSales;
	
	@FindBy(xpath="//*[@id=\"Body_ddlRequestReason\"]")
	public WebElement requestReason;
	
	@FindBy(xpath="//*[@id=\"Body_btnRequest\"]")
	public WebElement sendRequestRecovery;
	
	@FindBy(xpath="//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement cancelPrintRequest;
	
	//------------------------------------- addition for icomp request
	
	@FindBy(xpath= "//*[@id=\"DataTables_Table_0\"]/tbody/tr[2]/td[6]/div[2]")
	public WebElement icompButton;
	
	@FindBy(xpath="//*[@id=\"Modal_chkForSale_1\"]")
	public WebElement iCompselectforSales;
	
	@FindBy(xpath="//*[@id=\"Modal_ddlRequestReason\"]")
	public WebElement iCompRequestReason;
	
	@FindBy(xpath="//*[@id=\"IcompConfirmationModal\"]/div[2]/div/div[3]/button[1]")
	public WebElement IcompsendRequest;
//------------------------------------------------------ Addition for Partial request
	
	@FindBy(xpath= "//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[5]/div[2]")
	public WebElement PartialRequestButton;
	
	@FindBy(css= "#DataTables_Table_9 > tbody > tr:nth-child(2) > td.col-md-2.full-width.text-center.no-left-right-padding.cta > div > label")
	public WebElement clickPlusButton;
	
	@FindBy(xpath= "//*[@id=\"modalRequest\"]/div[2]/div/div[3]/button[2]")
	public WebElement PartialgoToRequestForm;
	
	@FindBy(xpath= "//*[@id=\"Modal_ddlReasons_iCompOrderFailed\"]")
	public WebElement partialselectReason;
	
	@FindBy(xpath= "//*[@id=\"Modal_LinkButton1\"]")
	public WebElement PartialgoToRequestPage;
	
	@FindBy(xpath= "//*[@id=\"Body_rptPartDetail_txtQty_0\"]")
	public WebElement entreValue;
	
	@FindBy(xpath= "//*[@id=\"Body_ddlRequestReason\"]")
	public WebElement partialSelectreasonforordering;
	
	@FindBy(xpath= "//*[@id=\"Body_btnRequest\"]")
	public WebElement PartialSendRequestToRecovery;
	
	@FindBy(xpath= "//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement PartialCancelPrint;
	
	//-------------------------------- Issue Report
	
	@FindBy(xpath= "//*[@id=\"DataTables_Table_0\"]/tbody/tr[1]/td[7]/div")
	public WebElement IssueReportIcon;
	
	@FindBy(xpath= "//div[@id='UnlinkRequestModal']/div[2]/div/div[2]/div/select[@id='Modal_ddlUnlinkRequestReason']")
	public WebElement IssueReportSelectReason;
	
	@FindBy(xpath= "//div[@id='UnlinkRequestModal']/div[2]/div/div[3]/button[@onclick='UnlinkRequest()']")
	public WebElement IssueReportOkButton;
	
	public void Cure_han_Request()
	{
		cuSearch.sendKeys("00355133");
		cuSearchbtn.click();
		articlebtndropdown.click();
		handoutButton.click();
		goToRequestForm.click();
		selectQuantity.sendKeys("1");
		selectforSales.click();
		Select select = new Select(requestReason);
		select.selectByVisibleText("Part was missing");
		sendRequestRecovery.click();
		cancelPrintRequest.click();
		
		
	}
	
	public void Cure_icomp_Request()
	{
		cuSearch.sendKeys("00355133");
		cuSearchbtn.click();
		articlebtndropdown.click();
		Set<String> winid = driver.getWindowHandles();
		Iterator<String> iterator = winid.iterator();
		String First_Window = iterator.next();
		icompButton.click();
		driver.switchTo().window(First_Window);
		iCompselectforSales.click();
		Select select = new Select(iCompRequestReason);
		select.selectByVisibleText("Part was missing");
		IcompsendRequest.click();
		
	}
	
	
	public void Cure_Partial_Request()
	{
		
		cuSearch.sendKeys("00355133");
		cuSearchbtn.click();
		articlebtndropdown.click();
		PartialRequestButton.click();
		WebDriverWait wait = new WebDriverWait(driver,20);
		clickPlusButton.click();
		PartialgoToRequestForm.click();
		Select select = new Select(partialselectReason);
		select.selectByVisibleText("The customer wanted the component now.");
		PartialgoToRequestPage.click();
		entreValue.sendKeys("1");
		Select select1 = new Select(partialSelectreasonforordering);
		select1.selectByVisibleText("Part was missing");
		PartialSendRequestToRecovery.click();
		PartialCancelPrint.click();
	}
	
	
	public void Cure_Issue_Report() throws Throwable 
	{
		
		cuSearch.sendKeys("00355133");
		cuSearchbtn.click();
		articlebtndropdown.click();
		WebDriverWait wait = new WebDriverWait(driver,20);
		IssueReportIcon.click();
		
		Select select1 = new Select(IssueReportSelectReason);
		select1.selectByVisibleText("Article - spare part link is missing");
	
		IssueReportOkButton.click();
		
		
	}
	
	
	
	
	

}
