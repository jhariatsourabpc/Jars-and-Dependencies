package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Recovery_Dashboard_Page extends Base_Page{

	public Recovery_Dashboard_Page(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath="//*[@id=\"NewRequestsTable\"]/tbody/tr[1]/td[1]")
	public WebElement articlebtndropdown;
	
	// ---- Accept Button
	
	@FindBy(xpath ="//*[@id=\"NewRequestsTable\"]/tbody/tr[1]/td[9]/div[1]")  
	public WebElement accept_Request_Button;
	@FindBy(xpath ="//*[@id=\"confirm\"]/div[2]/div/div[3]/button[1]")
	public WebElement okButton;
	// Add Stock
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]")
	public WebElement ManageStockMouseHover;
	@FindBy(xpath = "//*[@id=\"Body_txtSearch\"]")
	public WebElement SearchBox;
	@FindBy(xpath = "//div[@class = 'col-md-12 col-sm-12 col-lg-8 searchFormArea']/input[@type='submit']")
	public WebElement SearchButtonAddStock;
	@FindBy(xpath = "//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[1]")
	public WebElement DropDownAddStock;
	@FindBy(xpath = "//*[@id=\"DataTables_Table_0\"]/tbody/tr[1]/td[6]/span[1]")
	public WebElement AddButtonIcon;
	@FindBy(xpath = "//*[@id=\"txtQty\"]")
	public WebElement AddItemAddStock;
	@FindBy(xpath = "//*[@id=\"UpdateStockModal\"]/div[2]/div/div[3]/button[1]")
	public WebElement SaveButtonAddStock;
	
	// Delet Stock
	@FindBy(xpath = "//*[@id=\"DataTables_Table_0\"]/tbody/tr[1]/td[6]/span[2]")
	public WebElement DeleteItemButtonDeleteStock;
	@FindBy(xpath = "//*[@id=\"txtQty\"]")
	public WebElement AddItemDeleteStock;
	@FindBy(xpath = "//*[@id=\"Modal_ddlReason\"]")
	public WebElement DropDownDeleteStock;
	@FindBy(xpath = "//*[@id=\"UpdateStockModal\"]/div[2]/div/div[3]/button[1]")
	public WebElement SaveButtonDeleteStock;
	
	// Report Issue
	@FindBy(xpath = "//*[@id=\"DataTables_Table_0\"]/tbody/tr[1]/td[7]/div")
	public WebElement IssueReportButton;
	@FindBy(xpath = "//*[@id=\"Modal_ddlUnlinkRequestReason\"]")
	public WebElement DropDownIssueReport;
	@FindBy(xpath = "//*[@id=\"UnlinkRequestModal\"]/div[2]/div/div[3]/button[1]")
	public WebElement OkButtonIssueReport;
	
	// Add Spare Part
	@FindBy(xpath = "//*[@id=\"tbl_Articles\"]/tbody/tr[1]/td[5]/a[2]")
	public WebElement ButtonAddSparePart;
	@FindBy(xpath = "//*[@id=\"Modal_ddlGenericPartDesc\"]")
	public WebElement DropdownAddSparePart;
	@FindBy(xpath = "//*[@id=\"Modal_PartAndPosition\"]")
	public WebElement InputPartDescriptionAddSparePart;
	@FindBy(xpath = "//*[@id=\"CreateNCompModal\"]/div[2]/div/div[3]/button[1]")
	public WebElement SaveButtonAddSparePart;
	@FindBy(xpath = "//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement CancelButtonAddSparePart;
	
	//Add Location
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[4]/a")
	public WebElement LocationTabButton;
	@FindBy(xpath = "//div[@class='col-md-12 col-lg-12 searchFormArea location']/div[4]/input[2]")
	public WebElement AddButtonLocationTab;
	@FindBy(xpath = "//*[@id=\"txtLocation\"]")
	public WebElement NewLocationNameLocationTab;
	@FindBy(xpath = "//*[@id=\"txtLocationDesc\"]")
	public WebElement NewLocationDescriptionLocationTab;
	@FindBy(xpath = "//*[@id=\"InsertUpdateLocation\"]/div[2]/div/div[3]/div/button[1]")
	public WebElement SaveButtonLocationTab;
	
	// StockCheckInLocation
	
	@FindBy(xpath = "//*[@id=\"Body_rptLocation_Location_1\"]")
	public WebElement SelectCheckBox;
	@FindBy(css  = "#Body_StockCheckBtn")
	public WebElement ClickStockCheckButton;
	@FindBy(xpath  = "//*[@id=\"page-content-wrapper\"]/div[1]/div/div/div[2]/div[2]/div[1]")
	public WebElement DropdownStockCheck;
	@FindBy(xpath  = "//*[@id=\"page-content-wrapper\"]/div[1]/div/div/div[2]/div[3]/div[2]/div/div[4]/div[2]/div/span[2]")
	public WebElement AddQuantityButtonStockCheck;
	@FindBy(xpath  = "//*[@id=\"Body_lnkSave\"]")
	public WebElement SaveButtonStockCheck;
	
	
	
	
	public void recoveryacceptRequest()
	{
		articlebtndropdown.click();
		WebDriverWait wait = new WebDriverWait(driver,20);
		accept_Request_Button.click();
		WebDriverWait wait1 = new WebDriverWait(driver,20);
		okButton.click();
		
		
	}
	
	
	public void RecoveryAddStock() throws InterruptedException 
	{
		Actions ac = new Actions(driver);
		ac.moveToElement(ManageStockMouseHover).perform();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/ul/li[1]/a")).click();
		
		SearchBox.sendKeys("pax");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"Body_btnSearch\"]")).click();
		
		//SearchButtonAddStock.click();
		DropDownAddStock.click();
		AddButtonIcon.click();
		AddItemAddStock.sendKeys("2");
		SaveButtonAddStock.click();
	
	}
	
	public void RecoverydeleteStock() throws InterruptedException 
	{
		Actions ac = new Actions(driver);
		ac.moveToElement(ManageStockMouseHover).perform();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/ul/li[1]/a")).click();
		
		SearchBox.sendKeys("pax");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"Body_btnSearch\"]")).click();
		DropDownAddStock.click();
		DeleteItemButtonDeleteStock.click();
		AddItemDeleteStock.sendKeys("1");
		Select select = new Select(DropDownDeleteStock);
		select.selectByVisibleText("Missing");
		SaveButtonDeleteStock.click();
	}
	
	public void RecoveryIssueReport() throws InterruptedException 
	{
		Actions ac = new Actions(driver);
		ac.moveToElement(ManageStockMouseHover).perform();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/ul/li[1]/a")).click();
		
		SearchBox.sendKeys("pax");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"Body_btnSearch\"]")).click();
		DropDownAddStock.click();
		IssueReportButton.click();
		Thread.sleep(3000);
		Select select = new Select(DropDownIssueReport);
		select.selectByVisibleText("Article - spare part link is missing");
		OkButtonIssueReport.click();
		
		
	}
	
	public void RecoveryAddSparePart() throws InterruptedException 
	{
		Actions ac = new Actions(driver);
		ac.moveToElement(ManageStockMouseHover).perform();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/ul/li[1]/a")).click();
		
		SearchBox.sendKeys("pax");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"Body_btnSearch\"]")).click();
		DropDownAddStock.click();
		Thread.sleep(2000);
		ButtonAddSparePart.click();
		Thread.sleep(3000);
		Select select = new Select(DropdownAddSparePart);
		select.selectByVisibleText("Back Cushion");
		InputPartDescriptionAddSparePart.sendKeys("Test123");
		SaveButtonAddSparePart.click();
		Thread.sleep(3000);
		CancelButtonAddSparePart.click();
		
	}
	
	public void RecoveryAddLocation() throws InterruptedException
	{
		Thread.sleep(9000);
		LocationTabButton.click();
		WebElement ele = driver.findElement(By.xpath("//*[@id=\"page-content-wrapper\"]/div[1]/div/div/div[1]/div[4]/input[2]"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", ele);
		Thread.sleep(4000);
		NewLocationNameLocationTab.sendKeys("Test125");
		NewLocationDescriptionLocationTab.sendKeys("This Location is for Testing");
		SaveButtonLocationTab.click();
		
		
		
	}
	
	public void RecoveryAddLocationStockCheck() throws InterruptedException
	{
		Thread.sleep(9000);
		LocationTabButton.click();
		Thread.sleep(4000);
		SelectCheckBox.click();
		Thread.sleep(4000);
		
		WebElement ele = driver.findElement(By.cssSelector("#Body_StockCheckBtn"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", ele);
		Thread.sleep(4000);
		DropdownStockCheck.click();
		AddQuantityButtonStockCheck.click();
		SaveButtonStockCheck.click();
		
		
		
		
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		//ClickStockCheckButton.click();
		/*
		 * try {
		 * driver.findElement(By.xpath("//*[@id=\"Body_StockCheckBtn\"]")).click(); }
		 * catch (Exception e) { JavascriptExecutor executor = (JavascriptExecutor)
		 * driver; executor.executeScript("arguments[0].click();",
		 * driver.findElement(By.xpath("//*[@id=\"Body_StockCheckBtn\"]"))); }
		 */
		
		
	}
		
		
	
	
	
	
	
	
	
	
	

}
