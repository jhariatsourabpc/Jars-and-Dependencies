package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class Home_Page extends Base_Page {
	
	public Home_Page(WebDriver driver)
	{
		super(driver);
	}
	
	
	@FindBy(xpath="//*[@id=\"txtUser\"]")
	public WebElement username;
	
	@FindBy(xpath="//*[@id=\"txtPassword\"]")
	public WebElement password;
	
	@FindBy(xpath="//*[@id=\"btnLogin\"]")
	public WebElement loginBtn;
	
	@FindBy(xpath = "//*[@id=\"txtUser\"]")
	public WebElement recoveryUsername;
	
	@FindBy(xpath="//*[@id=\"txtPassword\"]")
	public WebElement recoverypassword;
	
	@FindBy(xpath="//*[@id=\"btnLogin\"]")
	public WebElement recoveryloginBtn;
	
	@FindBy(xpath= "//*[@id=\"changeUserRole\"]/ul/li/a/span")
	public WebElement SwitchToRecovery;
	
	public DashBoard_Page Cure_login()
	{
		username.sendKeys("river3");
		password.sendKeys("Omsystem@23");
		loginBtn.click();
		
		return new DashBoard_Page(driver);
		
		
	}
	
	public Recovery_Dashboard_Page RecoveryLogin()
	{
		recoveryUsername.sendKeys("river3");
		recoverypassword.sendKeys("Omsystem@34");
		recoveryloginBtn.click();
		Actions action = new Actions(driver);
		action.moveToElement(SwitchToRecovery).click(driver.findElement(By.xpath("//*[@id=\"Repeater1_SwitchUserRole_1\"]"))).perform();
		
		
		return new Recovery_Dashboard_Page(driver);
	}
   //	new
	public Recovery_Dashboard_Page RecoveryAdiminLogin()
	{
		recoveryUsername.sendKeys("river3");
		recoverypassword.sendKeys("Omsystem@34");
		recoveryloginBtn.click();
		Actions action = new Actions(driver);
		action.moveToElement(SwitchToRecovery).click(driver.findElement(By.xpath("//*[@id=\"Repeater1_SwitchUserRole_1\"]"))).perform();
		
		
		return new Recovery_Dashboard_Page(driver);
	}
	

}
